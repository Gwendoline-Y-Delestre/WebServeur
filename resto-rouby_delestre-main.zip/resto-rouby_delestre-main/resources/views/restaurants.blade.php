@extends('layouts\main')
@section('content')
    <h1>Restaurants</h1>
    <ul>
        @foreach ($restaurants as $restaurant)
            <li><a href="restaurants/{{ $restaurant->title }}">{{ $restaurant->title }}</a></li>
        @endforeach
    </ul>
@endsection
