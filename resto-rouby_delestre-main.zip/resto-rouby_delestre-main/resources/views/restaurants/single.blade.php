@extends('layouts\main')
@section('content')
    <h1>{{ $restaurant->title }}</h1>

    <?php
    $mean_note = 'Aucune note';
    if (count($comments) != 0) {
        $mean_note = 0;
        foreach ($comments as $comment) {
            $mean_note = $mean_note + $comment->note;
        }
        $mean_note = intval($mean_note / count($comments));
    }
    ?>
    <div>
        <p> Note moyenne : {{ $mean_note }}
        <p>
            Desciption : {{ $restaurant->content }}
        </p>
        <p>
            Propriétaire : {{ $restaurant->owner_id }}
            {{-- {{ $owner->name }} --}}
        </p>
        <p>
            Type de nourriture : {{ $restaurant->food_type_id }}
        </p>
        <p>
            {{-- Type de nourriture : {{ $food_type->type }} --}}
        </p>
        <p>
            Prix : {{ $restaurant->price }}
        </p>
        <p>
            Lien vers le restaurant : {{ $restaurant->url }}
        </p>
        <p>
            Tags : {{ $restaurant->tags }}
        </p>
        <p>
            Status : {{ $restaurant->status }}
        </p>
    </div>
    <div>
        <h6>Ajouter un commentaire :</h6>
        <form method="POST" action="/restaurants/{{ $restaurant->title }}">
            <div>
                <input type="text" name="author_id" placeholder="Pseudo" />
                <input type="hidden" name="restaurant_id" value="{{ $restaurant->id }}" />
                <input type="textarea" name="content" placeholder="Commentaire" />
                <label>Note sur 5:</label>
                <select name="note">
                    <option>1</option>
                    <option>2</option>
                    <option>3</option>
                    <option>4</option>
                    <option>5</option>
                </select>
                <br />
                <button type="submit">Envoyer</button>
            </div>
            @csrf
        </form>
        {{-- affichage des commentaires si on fait identidication afficher author name --}}
        <h6>Commentaires : </h6>
        <div>
            @foreach ($comments as $comment)
                <p>{{ $comment->note }} </p>
                <p> {{ $comment->content }}</p>
            @endforeach
        </div>
    </div>
@endsection
