@extends('layouts\main')
@section('content')
    <h1>Ajouter un restaurant</h1>

    <form method="POST" action="/admin/create">
        @method('POST')
        <div>
            <input type="text" name="title" placeholder="Nom du restaurant" />
            <label>Indiquez le propriétaire de l'établissement :</label>
            <select name="owner">
                {{-- creer requette pour obtenir tout les proprio
                    eventuellement modifier la base de données --}}
                @foreach ($owners as $owner)
                    <option> <?php echo $owner->name; ?></option>
                @endforeach
            </select>

            <input type="tewtarea" name="content" placeholder="Description" />
            <label>Indiquez le type de cuisine de l'établissement :</label>
            <select name="food_type">
                @foreach ($food_types as $food_type)
                    <option> <?php echo $food_type->type; ?></option>
                @endforeach
            </select>
            <input type="text" name="price" placeholder="Fourchette de prix" />
            <input type="url" name="url" placeholder="url" />
            <input type="text" name="tag" placeholder="Tag" />
            <label>Indiquez si l'établissement est ouvert ou non :</label>
            <select name="status">
                <option>Open</option>
                <option>Close</option>
            </select>
            <button type="submit">Envoyer</button>
        </div>
        @csrf
    </form>
@endsection
