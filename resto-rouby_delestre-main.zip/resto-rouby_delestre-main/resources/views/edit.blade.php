@extends('layouts\main')
@section('content')
    <h1>Modifier {{ $restaurant->title }}</h1>

    <form method="POST" action="/admin/edit">
        @method('PUT')
        <div>
            <input type="text" name="title" placeholder="{{ $restaurant->title }}" />
            <?php echo $owners; ?>
            <select id="proprio" name="owner">
                {{-- creer requette pour obtenir tout les proprio
                    eventuellement modifier la base de données --}}
                {{-- @foreach ($owners as $owner)
                <option> <?php //echo $owner->name
                ?></option>
                @endforeach --}}
                <option>Test</option>
                <option>Test</option>
                <option>Test</option>
                <option>Test</option>
            </select>

            <input type="tewtarea" name="content" placeholder="{{ $restaurant->content }}" />
            <input type="text" name="food_type" placeholder="{{ $restaurant->food_type }}" />
            <input type="text" name="price" placeholder="{{ $restaurant->price }}" />
            <input type="url" name="url" placeholder="{{ $restaurant->url }}" />
            <input type="text" name="tag" placeholder="{{ $restaurant->tags }}" />
            <select name="status">
                {{-- creer requette pour obtenir tout les proprio
                    eventuellement modifier la base de données --}}
                {{-- @foreach ($owners as $owner)
                <option> <?php //echo $owner->name
                ?></option>
                @endforeach --}}
                <option>Open</option>
                <option>Close</option>
            </select>
            <button type="submit">Envoyer</button>
        </div>
        @csrf
    </form>
@endsection
