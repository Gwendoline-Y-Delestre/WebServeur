@extends('layouts\main')
@section('content')
    <h1>Restaurants vue admin</h1>
    <button onclick="window.location.href = '/admin/create'">Ajouter</button>
    <ul>
        @foreach ($restaurants as $restaurant)
            <div>
                <li><a href="restaurants/{{ $restaurant->title }}">{{ $restaurant->title }}</a>
                    <button onclick="window.location.href = '/admin/edit';">Modifier</button>
                    <button onclick="window.location.href = '/admin/destroy';">Supprimer</button>
                </li>
            </div>
        @endforeach
    </ul>
@endsection
