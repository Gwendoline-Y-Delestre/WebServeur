@extends('layouts\main')
@section('content')
    <h1>Contact</h1>

    <form method="POST" action="/contacts">

        <div>
            <label>Choisissez qui vous voulez contater</label>
            <select name="destinataire">
                @foreach ($restaurants as $restaurant)
                    <option> <?php echo $restaurant->title; ?></option>
                @endforeach
                <option>Pour l'administrateur</option>
            </select>
            <input type="text" name="name" placeholder="Name" />
            <input type="email" name="email" placeholder="Email" />
            <input type="text" name="message" placeholder="Message" />
            <button type="submit">Envoyer</button>
        </div>
        @csrf
    </form>
@endsection
