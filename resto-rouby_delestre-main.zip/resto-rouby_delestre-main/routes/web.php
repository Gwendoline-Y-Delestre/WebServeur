<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
use App\Http\Controllers\HomeController;

Route::get('/', [HomeController::class, 'index']);
Route::get('/restaurants/{url}', [HomeController::class, 'show']);

use App\Http\Controllers\ContactsController;

Route::get('/contacts', [ContactsController::class, 'index']);
Route::post('/contacts', [ContactsController::class, 'store']);

use App\Http\Controllers\RestaurantsController;

Route::get('/restaurants', [RestaurantsController::class, 'index']);
Route::get('/restaurants/{url}', [RestaurantsController::class, 'show']);

use App\Http\Controllers\CommentsController;
Route::get('/restaurants/{url}', [CommentsController::class, 'show']);
Route::post('/restaurants/{url}', [CommentsController::class, 'store']);

use App\Http\Controllers\AdminRestaurantsController;

Route::resource('/admin', AdminRestaurantsController::class);

Route::get('/admin/create', [AdminRestaurantsController::class,'create']);
Route::post('/admin/create', [AdminRestaurantsController::class, 'store']);

Route::get('/admin/edit', [AdminRestaurantsController::class, 'edit']);
Route::post('/admin/edit', [AdminRestaurantsController::class, 'update']);

// ===============================================================
// creer a partir de authentification

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';

//==================================================================
// socialite

use Laravel\Socialite\Facades\Socialite;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
// Github
Route::get('/auth/redirect', function () {
    // ->scopes(['read:user', 'public_repo'])
    return Socialite::driver('github')->stateless()->redirect();
});
Route::get('/auth/callback', function () {
    $githubUser  = Socialite::driver('github')->user();

    // $user->token

    $user = User::updateOrCreate([
        'github_id' => $githubUser->id,
    ], [
        'name' => $githubUser->name,
        'email' => $githubUser->email,
        // 'role' => 'utilisateur',
        'github_token' => $githubUser->token,
        'github_refresh_token' => $githubUser->refreshToken,
    ]);

    // OAuth 2.0 providers...
    // $token = $user->token;
    // $refreshToken = $user->refreshToken;
    // $expiresIn = $user->expiresIn;
    //$user = Socialite::driver('github')->userFromToken($token);

    // OAuth 1.0 providers...
    // $token = $user->token;
    // $tokenSecret = $user->tokenSecret;
    // $user = Socialite::driver('twitter')->userFromTokenAndSecret($token, $secret);

    // All providers...
    $githubUser->getId();
    // $user->getNickname();
    $githubUser->getName();
    $githubUser->getEmail();

    Auth::login($user);

    return redirect('/dashboard');
});
// Google
// Route::get('/auth/redirect', function () {
//     return Socialite::driver('google')->redirect();
// });
// Route::get('/auth/callback', function () {
//     $user = Socialite::driver('google')->user();

//     // $user->token
// });
// // Facebook
// Route::get('/auth/redirect', function () {
//     return Socialite::driver('facebook')->redirect();
// });
// Route::get('/auth/callback', function () {
//     $user = Socialite::driver('facebook')->user();

//     // $user->token
// });


//Google
Route::get('/login/google', [App\Http\Controllers\Auth\LoginController::class, 'redirectToGoogle'])->name('login.google');
Route::get('/login/google/callback', [App\Http\Controllers\Auth\LoginController::class, 'handleGoogleCallback']);
//Facebook
Route::get('/login/facebook', [App\Http\Controllers\Auth\LoginController::class, 'redirectToFacebook'])->name('login.facebook');
Route::get('/login/facebook/callback', [App\Http\Controllers\Auth\LoginController::class, 'handleFacebookCallback']);
//Github
Route::get('/login/github', [App\Http\Controllers\Auth\LoginController::class, 'redirectToGithub'])->name('login.github');
Route::get('/login/github/callback', [App\Http\Controllers\Auth\LoginController::class, 'handleGithubCallback']);
