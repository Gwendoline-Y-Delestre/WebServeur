<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class FoodTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('food_types')->insert([
            'id' => 1,
            'type' => 'Pizza',
            'description' => 'Recette traditionnelle à base de galette de pâte à pain',
            'zone' => 'Italie',
        ]);

        DB::table('food_types')->insert([
            'id' => 2,
            'type' => 'Sushis',
            'description' => "Plat traditionnel japonais, composé d'un riz vinaigré et de poisson cru",
            'zone' => 'Japon',
        ]);
        DB::table('food_types')->insert([
            'id' => 3,
            'type' => 'Savoyard',
            'description' => "Cette cuisine se caractérise à la fois par sa simplicité et l'utilisation de produits locaux, à base en grande partie de charcuteries et fromages de montagne",
            'zone' => 'Savoie/Haute-Savoie, France',
        ]);
        DB::table('food_types')->insert([
            'id' => 4,
            'type' => 'Antillaise',
            'description' => 'Cuisine traditionnelle qui mélange les produits et traditions culinaires créoles de tous les peuples qui ont fait escale aux Antilles françaises. Des grillades épicées des Indiens caraïbes en passant par le calalou africain, la brandade de morue française ou le colombo indien',
            'zone' => 'Antilles, France',
        ]);
        DB::table('food_types')->insert([
            'id' => 5,
            'type' => 'Libanaise',
            'description' => " Composée principalement d’entrées appelées aussi « mezés » riches en légumes et en épices, ainsi que de grillades",
            'zone' => 'Liban',
        ]);
    }
}
