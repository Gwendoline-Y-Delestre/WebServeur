<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Comment>
 */
class CommentFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        //$title = $this->faker->company();

        return [
            'author_id' => fake()->numberBetween(1,10),
            'restaurant_id' => fake()->numberBetween(1,10), //\App\Models\restaurant::factory(),
            'content' => $this->faker->paragraph($nbSentences = 10, $variableNbSentences = true),
            'note' => fake()->numberBetween(1,5)];
    }
}
