<?php

namespace App\Http\Controllers;
use App\Models\contact;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class ContactsController extends Controller
{
    function index()
    {
        $restaurants = \App\Models\restaurant::all();
        return view('contact', array(
            'restaurants' => $restaurants));
    }


    public function store()
    {
        $contact = new contact();
        // $contact = request()->all();
        // modifier si on fai un lien entre la table restaurants et contact
        $contact->name = request('name');
        $contact->email = request('email');
        $contact->destinataire = request('destinataire');
        $contact->message = request('message');
        $contact->updated_at = date('y-m-d h:i:s');
        $contact->created_at = date('y-m-d h:i:s');


        $contact->save();
        return redirect('/contacts');
    }
}
