<?php

namespace App\Http\Controllers;
use App\Models\comment;
use Illuminate\Http\Request;

class CommentsController extends Controller
{
    function index()
    {
        return view('restaurants');
    }

    public function show($restaurant_name)
    {
        //get first restaurant with restaurant_name == $restaurant_name
        $restaurant = \App\Models\restaurant::where('title', $restaurant_name)->first();
        $comments = comment::where('restaurant_id', $restaurant->id)->get();
        return view('restaurants/single', array(//Pass the restaurant to the view
            'restaurant' => $restaurant,
            'comments' => $comments
        ));
    }

    public function store()
    {
        $comment = new comment();
        // $contact = request()->all();

        $comment->author_id = request('author_id');
        $comment->restaurant_id = request('restaurant_id');
        $comment->content = request('content');
        $comment->note = request('note');
        $comment->updated_at = date('y-m-d h:i:s');
        $comment->created_at = date('y-m-d h:i:s');


        $comment->save();
        return redirect('/restaurants');
    }
}
