<?php

namespace App\Http\Controllers;

use App\Models\restaurant;
use Illuminate\Http\Request;
use App\Models\User;



class AdminRestaurantsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $restaurants = restaurant::all();

        return view('admins', array('restaurants' => $restaurants));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $owners = User::where('role','proprietaire')->get();
        $restaurants = restaurant::all();
        $food_types = \App\Models\food_type::all();
        return view('admins/create',array('restaurants' => $restaurants,
                                            'owners'=>$owners,
                                            'food_types' => $food_types,));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store()
    {
        $food_type = \App\Models\food_type::where('type', request('food_type') )->first();
        $food_type_id = $food_type->id;
        $restaurant = new restaurant();
        // $contact = request()->all();

        $restaurant->title = request('title');
       // $restaurant->owner = request('owner');
        $restaurant->owner_id = 1;
        $restaurant->content = request('content');
        $restaurant->food_type_id = $food_type_id;
        $restaurant->price = request('price');
        $restaurant->url = request('url');
        $restaurant->tags = request('tag');
        $restaurant->status = request('status');
        $restaurant->updated_at = date('y-m-d h:i:s');
        $restaurant->created_at = date('y-m-d h:i:s');

        $restaurant->save();
        return redirect('/admin');
    }

    /**
     * Display the specified resource.
     */
    public function show($restaurant_name)
    {
        $restaurant = \App\Models\restaurant::where('title', $restaurant_name)->first(); //get first restaurant with restaurant_nam == $restaurant_name

        return view('admins', array('restaurant' => $restaurant));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit()//string $id)
    {
        // $owners = User::all(); // modifier si on change la bdd
        // $restaurant = \App\Models\restaurant::where('id', $id)->first();
        // $restaurants = \App\Models\restaurant::all();
        // return view('admins', array(
        //     'restaurants' => $restaurants,'owners' => $owners ));
            //Pass the restaurant to the view et tout les owner
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $restaurant = \App\Models\restaurant::where('id', $id)->first();
        $restaurant->title = request('title');
        // $restaurant->owner = request('owner');
         $restaurant->owner_id = 1;
         $restaurant->content = request('content');
         $restaurant->food_type = request('food_type');
         $restaurant->price = request('price');
         $restaurant->url = request('url');
         $restaurant->tags = request('tag');
         $restaurant->status = request('status');
         $restaurant->updated_at = date('y-m-d h:i:s');
         $restaurant->created_at = date('y-m-d h:i:s');

         $restaurant->save();
         return redirect('/admin');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        // echo "supprimer";
    }
}
