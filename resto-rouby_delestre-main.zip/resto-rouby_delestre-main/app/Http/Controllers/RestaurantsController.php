<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class RestaurantsController extends Controller
{
    function index()
    {
        // permet d'afficher tous les restaurants dans la page restaurants
        $restaurants = \App\Models\restaurant::all();

        return view('restaurants', array(
            'restaurants' => $restaurants
        ));
    }

    public function show($restaurant_name)
    {
        $restaurant = \App\Models\restaurant::where('title', $restaurant_name)->first(); //get first restaurant with restaurant_nam == $restaurant_name
        $comments = \App\Models\comment::where('restaurant_id', $restaurant->id); //get comment pour un restau en particulier
        #TODO

        $food_type_id = $restaurant->food_type_id;
        // $food_type = \App\Models\food_type::select('SELECT type FROM food_types INNER JOIN restaurants ON restaurants.food_type_id=food_types.id', ['id' => 1]);
        $food_type = DB::table('food_types')->where('id', $food_type_id)->first();

        // $food_type = \App\Models\food_type::join('restaurants','food_types.id', '=', 'restaurants.food_type_id')->get();
        // $foods = \App\Models\food_type::select('SELECT type FROM food_types INNER JOIN restaurants ON restaurants.food_type_id=food_types.id', ['id' => 1]);
        // SELECT type FROM "food_types" INNER JOIN "restaurants" ON restaurants.food_type_id=food_types.id;
        // $owner = User::where('restaurant_id', $restaurant->owner_id)->get();
        // SELECT name FROM "users" INNER JOIN "restaurants" ON restaurants.owner_id=users.id;
        // $food_type = \App\Models\food_type::where('id', $restaurant->food_type_id);
        // if (empty($food_type)) {
        //     return view('restaurants/single', array('restaurant' => $restaurant,
        //     // 'owner' => $owner,
        //     'comments' => $comments,
        //     'food_type' =>  'erreur'));}
        // else {
        //     return view('restaurants/single', array('restaurant' => $restaurant,
        //      // 'owner' => $owner,
        //     'comments' => $comments,
        //     'food_type' => $food_type

        //     ));}

        return view('restaurants/single', compact('restaurant', 'comments', 'food_type'));
        //array('restaurant' => $restaurant,
        //     // 'owner' => $owner,
        //     'comments' => $comments,
        //    'food_type' =>  'erreur'));

    }
}
