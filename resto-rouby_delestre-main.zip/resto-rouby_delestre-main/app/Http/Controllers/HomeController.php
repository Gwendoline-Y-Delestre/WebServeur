<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class HomeController extends Controller
{
    function index(){
        $restos = DB::table('restaurants')
            ->selectRaw('*')
            ->orderByDesc('id')
            ->limit(3)
            ->get();

        return view('welcome', array('restos' => $restos));
    }
}
