# Guide d'installation
 - git clone ... , 
 - composer install, 
    - composer require laravel/breeze --dev
    - php artisan breeze:install
    - composer require laravel/socialite
    - composer require laravel/ui
 - npm install, 
    - npm install
    - npm run dev
 - modification du fichier .env, 
    - modifier la ligne 14 et remplacer le chemin par l'amplacement du fichier .datasqlite de votre ordinateur
 - lancement des migrations, 
    - php artisan migrate:fresh --seed
 - lancement du ou des serveurs, etc.
    - php artisan serve
 
# Parties implémentées
### Propositions de parties a implémentées
- identification admin / socialite ( 2 / 2 )
- gestion des food_type (eventuellement rechercher par food_type si on a le temps) ( 2 )


### Description
+ Ajout de commentaires : 
    + Sur la page d’un restaurant il est possible d’ajouter un commentaire qui apparaitra en bas de la page une fois publié.
    + Pour tester, cliquez sur un restaurant, descendez en bas de la page, ajoutez un pseudo et tapez le commentaire puis valider.
+ Ajout de notes : 
    - Lorsque que l’on ajoute un commentaire, il y a également un champ « note » permettant d’attribuer une note sur 5 qui est publié en même temps que le commentaire.   
    - La moyenne des notes attribués au restaurant apparait sur la page.
        - Pour tester, sélectionnez une note de 1 à 5 dans le champ « note » au moment d’ajouter un commentaire. 
+ Gestion du type de cuisine :
+	Authentification : il est possible de créer un compte ou de se connecter si l’on en a déjà un.
    +	Pour tester, cliquez en haut sur « créer un compte ». Il y a différents champs à remplir sur la page puis il faut valider. Pour vous connectez, cliquez sur connexion et remplissez les champ puis validez.


## Remarques


# Commenter le code 
# Todo : 

```diff
- *modifier la table Users pour avoir des catégories d'user*
    - *modifier dans adminrestaurantscontroller la var $owners de create pour n'avoir que les owners*
+ *modifier la table contacts pour envoyer un message uniquement a un restau*
- *dans ajout restau de l'admin : afficher que les proprios*
! vue différentes suivants le role
        ! afficher le message au propriétaire du restau
        ! afficher message pour admin
        ! ajouter bouton pour acceder rapidement a /admin
- trouver pk foods et owner sont 'undefined'
    - rechercher par type_food
+ modifier les views quand on est log in et profil
- *label dans les formulaires*
+ commentaires : récupérer nom personne qui écrit 
- contact : ajouter nom de la personne log in dans la table et dans l'affichage
- *contact : envoyer a l'admin*
+ *enregistrement de nouveau utilisateurs*
    + faire en sorte qu'un propriétaire puisse ajouter un restaurant quand il s'inscrit
    + socialite a revoir
- **revoir seeders et factory**
+ **faire le schéma de la bdd**
```
# code d'autre personne :
https://www.honeybadger.io/blog/laravel-oauth/
